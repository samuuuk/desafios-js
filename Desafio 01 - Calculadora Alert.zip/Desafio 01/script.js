// Calculando números

alert("Bem-vindo a calculadora, pressione OK para continuar")
let firstNumber = Number(prompt("Digite o primeiro número: "))
let secondNumber = Number(prompt("Digite o segundo número: "))

let sum = firstNumber + secondNumber
let sub = firstNumber - secondNumber
let multi = firstNumber * secondNumber
let div = firstNumber / secondNumber
let restDiv = firstNumber % secondNumber

alert(`A soma desses números é: ${sum} `)
alert(`A subtração desses números é: ${sub} `)
alert(`A multiplicação desses números é: ${multi} `)
alert(`A divisão desses números é: ${div.toFixed(2)} `)
alert(`O resto de divisão desses números é: ${restDiv} `)

if(sum % 2 === 0) {
  alert("A soma dos dois números é par")
} else {
  alert("A soma dos dois números é impar")
}

if(firstNumber === secondNumber) {
  alert("Os números inseridos são iguais")
} else {
  alert("Os números inseridos são diferentes")
}