// Calculando médias

let students = [
{
  name: "Samuel",
  classroom: "1A",
  n1: 0,
  n2: 0,
  n3: 0,
},
{
  name: "Diego",
  classroom: "2B",
  n1: 0,
  n2: 0,
  n3: 0,
},
{
  name: "Pedro",
  classroom: "3A",
  n1: 0,
  n2: 0,
  n3: 0,
},
{
  name: "Lucas",
  classroom: "2C",
  n1: 0,
  n2: 0,
  n3: 0,
}
]

for(let index = 0; index < students.length; index++) {
  let grade1 = Number(prompt(`Aluno(a) ${students[index].name} \nDigite a primeira nota:`))
  let grade2 = Number(prompt(`Aluno(a) ${students[index].name} \nDigite a segunda nota:`))
  let grade3 = Number(prompt(`Aluno(a) ${students[index].name} \nDigite a terceira nota:`))
  students[index].n1 = grade1
  students[index].n2 = grade2
  students[index].n3 = grade3
}

function resultAverage(n1, n2, n3) {
  let average = ((n1 + n2 + n3) / 3).toFixed(1)
  return average
}

function finalMessage(student) {
  if(resultAverage(student.n1, student.n2, student.n3)>= 7) {
    alert(`A média do(a) aluno(a) ${student.name} foi de: ${resultAverage(student.n1, student.n2, student.n3)} \nParabéns, ${student.name}! Você foi aprovado(a) no concurso.`)
  } else {
    alert(`A média do(a) aluno(a) ${student.name} foi de: ${resultAverage(student.n1, student.n2, student.n3)} \nNão foi dessa vez, ${student.name}! Tente novamente mais tarde.`)
  }
}

for(student of students) {
  finalMessage(student)
}